<?php
require("admin_dbcon.php");
$u_id=base64_decode($_GET['u_id']);
$_SESSION['userid']=$u_id;
echo $_SESSION['userid'];


?>
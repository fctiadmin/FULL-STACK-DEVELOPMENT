<?php 
require("admin_dbcon.php");



?>

<div class="dasboard">
    <h1>Dashboard <small>Statistics Overview</small></h1>
    <div class="p-2" style="background:#f5f5f5;"><a href="admin_index.php?page=user_list">User List</a></div>
</div>
<div class="user_list">
<table id="myTable" class="display">
    <thead>
        <tr>
            <th>Id</th>
            <th>Username</th>
            <th>Email</th>
            <th>Mobile</th>
            <th>View</th>
            <th>Edit</th>
        </tr>
    </thead>
    <tbody>
      
    <?php
      $select = mysqli_query($db_con , "SELECT * FROM `admin_users`");
      while($rows=mysqli_fetch_assoc($select)){
    ?>
            <tr>
                <td><?php echo $rows['id'] ?></td>
                <td><?=$rows['username']?></td>
                <td><?=$rows['email']?></td>
                <td><?=$rows['mobile']?></td>
                <td><a href="profile_view.php?u_id=<?=base64_encode($rows['id'])?>">View</a></td>
                <td><a target="_blank" href="edit_user.php?&u_edit_id=<?=base64_encode($rows['id'])?>">edit</a></td>
            </tr>
    <?php
      }
    ?>
    </tbody>
    
</table>
</div>

<?php 
require("admin_dbcon.php");



?>

<div class="dasboard">
    <h1>Dashboard <small>Statistics Overview</small></h1>
    <div class="p-2" style="background:#f5f5f5;"><a href="admin_index.php?page=user_list">User List</a></div>
</div>
<div class="user_list">
<table id="myTable" class="display">
    <thead>
        <tr>
            <th>Id</th>
            <th>Username</th>
            <th>Email</th>
            <th>Mobile</th>
            <th>View</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
    </thead>
    <tbody>
      
    <?php
      $select = mysqli_query($db_con , "SELECT * FROM `admin_users`");
      while($rows=mysqli_fetch_assoc($select)){
    ?>
            <tr>
                <td><?php echo $rows['id'] ?></td>
                <td><?=$rows['username']?></td>
                <td><?=$rows['email']?></td>
                <td><?=$rows['mobile']?></td>
                <td><a href="profile_view.php?u_id=<?=base64_encode($rows['id'])?>">View</a></td>
                <td><a target="_blank" href="" data-bs-toggle="modal" data-bs-target="#exampleModal<?=$rows['id'];?>">Edit</a>
            
            <!-- edit section start -->
<!-- Modal -->
<div class="modal fade" id="exampleModal<?=$rows['id'];?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">User update form</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
     
	  <form action="update.php" method="POST" enctype="multipart/form-data">
      <div class="modal-body">
      <div class="row">
        <div class="col">
            <div class="input-group mb-2">
                <input type="hidden" class="form-control" name="u_id" id="u_id" value="<?=$rows['id']?>">
                <input type="text" placeholder="Username" class="form-control" name="username" id="username" value="<?=$rows['username']?>">
            </div>
            <div class="input-group mb-2">
                <input type="text" placeholder="email" class="form-control" name="email" id="email" value="<?=$rows['email']?>">
            </div>
            <div class="input-group mb-2">
                <input type="text" placeholder="mobile" class="form-control" name="mobile" id="mobile" value="<?=$rows['mobile']?>">
            </div>
        </div>
      </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <input type="submit" name="update" class="btn btn-primary" value="Update">
      </div>
	  </form>
    </div>
  </div>
</div>

            <!-- edit section end -->
            
            
            
            </td>
                <td><a  onclick="return confirm('Are you sure delete this data!')" target="_blank" href="delete.php?&u_del_id=<?=base64_encode($rows['id'])?>">Delete</a></td>
            </tr>
    <?php
      }
    ?>
    </tbody>
    
</table>
</div>

<?php 
require("admin_dbcon.php");
session_start();
if(!isset($_SESSION['user_login'])){
    header("location:admin_login_index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- css link start-->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/admin_dashboard.css">
	<link rel="stylesheet" href="css/jquery.dataTables.min.css">
    <!--css link end-->
	<!-- font-awesome cdn -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/boxicons/2.1.4/dist/boxicons.js"></script>
    <title>Md Alif - Dashboard</title>
</head>

<body>
<div class="main_body">
	<div class="logo_and_profile_icon">
		<div class="l_a_p_i_row">
			<div class="l_a_p_i_col">
              <div class="logo">
				<img height="100px" src="images/logo.png" alt="">
			  </div>
			</div>
			<div class="l_a_p_i_col">
				<div class="notifaction">

				</div>
				<div class="user_name">
					<p>MD ALIF</p>
				</div>
				<div class="user_photo" id="user_photo">
					<img  src="images/profile_picture.png" alt="">
				</div>
			</div>
		</div>
	</div>


	<div class="container-fluid" style="padding-left:0;position:relative">
		<div class="row">
			<div class="col col-sm-12 col-md-12 col-lg-3 col-xxl-2">
			<nav class="sidebar card">
						<ul class="nav flex-column" id="nav_accordion">
							<li class="nav-item">
								<a class="list-group-item dashboard" href="admin_index.php?page=admin_dashboard"><i class='bx bxs-dashboard'></i>Dashboard</a>
							</li>
							<li class="nav-item has-submenu">
								<a class="nav-link list-group-item" href="#">Admission</a>
								<ul class="submenu collapse">
									<li><a class="nav-link" href="admin_index.php?page=admission_page">Admission</a></li>
									<li><a class="nav-link" href="admin_index.php?page=admission_list_page">Admission list</a></li>
								</ul>
							</li>
							<li class="nav-item has-submenu">
								<a class="nav-link list-group-item" href="#">Teachers</a>
								<ul class="submenu collapse">
									<li><a class="nav-link" href="admin_index.php?page=add_teacher_page">Add Teacher </a></li>
									<li><a class="nav-link" href="admin_index.php?page=teacher_list_page">Teacher List</a></li>
									<li><a class="nav-link" href="admin_index.php?page=add_teacher_salary_page">Add Salary</a></li>
									<li><a class="nav-link" href="admin_index.php?page=salary_list_page">Salary List</a></li>
								</ul>
							</li>	
							<li class="nav-item has-submenu">
						
								<a class="nav-link list-group-item" href="admin_index.php?page=setting_page">Setting</a>
								<a class="nav-link list-group-item" href="admin_index.php?page=user_list">User List</a>

							</li>
												
						</ul>
					</nav>
			</div>
			<div class="col col-sm-12 col-md-12 col-lg-9 col-xxl-10">
                <?php 
				if(isset($_GET['page'])){
				$page=$_GET['page'].'.php';
				} else {
				$page='admin_dashboard.php';
				}
								
				if(file_exists($page)){
				require $page;
				} else {
					require '404.php';
				}				  
				?>
			</div>
		</div>
	</div>
</div>


<div class="footer-bottom" style="bottom: 0px;">
<div class="copyright"><p>Copyright  2012 FCTI Inc all rights reserved | Powered by <a target="_blank" href="https://fctisoftware.com">FCTI</a></p></div>
</div>

<button id="scrollTopBtn"><i class="fa-solid fa-arrow-up"></i></button>
<script src="js/bootstrap.min.js"></script>
<script src="js/script.js"></script>
<script src="js/jquery-3.7.1.js"></script>
<script src="js/jquery.dataTables.min.js"></script>

<script>

$(document).ready( function () {
    $('#myTable').DataTable();
} );
</script>



</body>
</html>
-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 01, 2024 at 12:27 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `php_full_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `admission_form`
--

CREATE TABLE `admission_form` (
  `id` int(11) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `father_name` varchar(100) NOT NULL,
  `mother_name` varchar(100) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `religion` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `job_title` varchar(100) NOT NULL,
  `blood_group` varchar(100) NOT NULL,
  `nid_birth_certificate` varchar(100) NOT NULL,
  `course_type` varchar(100) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `guardian_number` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `division` varchar(100) NOT NULL,
  `district` varchar(100) NOT NULL,
  `thana` varchar(100) NOT NULL,
  `post_office` varchar(100) NOT NULL,
  `village` varchar(100) NOT NULL,
  `session` varchar(100) NOT NULL,
  `exam_year` varchar(100) NOT NULL,
  `course` varchar(100) NOT NULL,
  `registration_type` varchar(100) NOT NULL,
  `total_fee` varchar(100) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `admission_time` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `ssc_board` varchar(100) NOT NULL,
  `ssc_roll` varchar(100) NOT NULL,
  `ssc_year` varchar(100) NOT NULL,
  `ssc_gpa` varchar(100) NOT NULL,
  `jsc_board` varchar(100) NOT NULL,
  `jsc_roll` varchar(100) NOT NULL,
  `jsc_year` varchar(100) NOT NULL,
  `jsc_gpa` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admission_form`
--

INSERT INTO `admission_form` (`id`, `student_name`, `father_name`, `mother_name`, `dob`, `religion`, `gender`, `job_title`, `blood_group`, `nid_birth_certificate`, `course_type`, `phone_number`, `guardian_number`, `email`, `division`, `district`, `thana`, `post_office`, `village`, `session`, `exam_year`, `course`, `registration_type`, `total_fee`, `photo`, `admission_time`, `status`, `ssc_board`, `ssc_roll`, `ssc_year`, `ssc_gpa`, `jsc_board`, `jsc_roll`, `jsc_year`, `jsc_gpa`) VALUES
(6, 'MD Alif', 'MD Faruk Matabber', 'Halima Begum', '2005-02-18', 'Islam', 'Male', 'Student', 'B+', '20075415423107551', 'Online', '01881162313', '01810929955', 'mdalif5218@gmail.com', 'Dhaka', 'Madaripur', 'Madaripur Sadar', 'Madaripur-7900', 'Mohisher Char , Ferighat', 'June-December', '2021', 'COA', 'Government', '56090', 'ceo-profile-img.jpg', '12-04-2023,11:54:42 am', 'Active', 'Dhaka', '210615', '2021', '4.94', 'Dhaka', '210618', '2019', '4.50'),
(7, 'MD Sabbir', 'Md Salam Sardar', 'Salma Begum', '2005-04-18', 'Islam', 'Male', 'student', 'B+', '20054534534535', 'Online', '01921080801', '01928248173', 'mdsabbir@gmail.com', 'Dhaka', 'Madaripur', 'Madaripur Sadar', 'Madaripur-7900', 'Mohisher Char Ferighat', 'January-June', '2022', 'web design', 'Government', '5600', 'avator.png', '12-06-2023,03:20:27 pm', 'Inactive', '', '', '', '', '', '', '', ''),
(8, 'MD Sifat', 'MD Salim Sarder', 'Salma Begum', '2004-02-18', 'Islam', 'Male', 'student', 'B+', '2005454234543', 'Offline', '01758771018', '01810929955', 'mdalif5218@gmail.com', 'Dhaka', 'Madaripur', 'Madaripur Sadar', 'Madaripur-7900', 'Mohisher Char , Ferighat', 'June-December', '2021', 'COA', 'Government', '5600', 'avator.png', '12-09-2023,09:46:52 am', 'Inactive', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `all_courses`
--

CREATE TABLE `all_courses` (
  `id` int(100) NOT NULL,
  `course_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `all_courses`
--

INSERT INTO `all_courses` (`id`, `course_name`) VALUES
(4, 'COMPUTER OFFICE APPLICATION'),
(5, 'FULL STACK WEB DEVELOPMENT'),
(7, 'Degital Marketing'),
(8, 'Vedio Editing'),
(9, 'Web Design'),
(10, 'Web Development'),
(11, 'SEO'),
(12, 'COA'),
(13, 'web design');

-- --------------------------------------------------------

--
-- Table structure for table `institute_logo`
--

CREATE TABLE `institute_logo` (
  `id` int(11) NOT NULL,
  `logo` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `institute_logo`
--

INSERT INTO `institute_logo` (`id`, `logo`) VALUES
(1, 'site-icon.png');

-- --------------------------------------------------------

--
-- Table structure for table `user_register_data`
--

CREATE TABLE `user_register_data` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `father name` varchar(100) NOT NULL,
  `mother name` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `register time` text NOT NULL,
  `status` varchar(100) NOT NULL,
  `photo` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_register_data`
--

INSERT INTO `user_register_data` (`id`, `name`, `username`, `father name`, `mother name`, `phone`, `email`, `address`, `password`, `register time`, `status`, `photo`) VALUES
(1, 'MD Alif', 'mdalif5218', 'Md Faruk Matabber', 'Halima Begum', '01758771018', 'webcoderalif5218@gmail.com', 'Old Bus Stand , Madaripur', '25f9e794323b453885f5181f1b624d0b', '2023-11-14 10:21:00am', 'Active', 'profile_picture.png'),
(3, 'MD Sabbir', 'sabbir', 'MD Salim Sarder', 'Salma Begum', '01921080801', 'mdsabbir@gmail.com', 'Mohisher Char Ferighat', '25f9e794323b453885f5181f1b624d0b', '2023-12-18 12:45:47pm', 'Active', 'ceo-profile-img.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admission_form`
--
ALTER TABLE `admission_form`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `all_courses`
--
ALTER TABLE `all_courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `institute_logo`
--
ALTER TABLE `institute_logo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_register_data`
--
ALTER TABLE `user_register_data`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admission_form`
--
ALTER TABLE `admission_form`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `all_courses`
--
ALTER TABLE `all_courses`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `institute_logo`
--
ALTER TABLE `institute_logo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_register_data`
--
ALTER TABLE `user_register_data`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

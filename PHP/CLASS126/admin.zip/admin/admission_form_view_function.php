<?php
	require_once 'db_con.php';
	session_start();
    $admission_id=base64_decode($_GET['admission_id']);
    if($admission_id){
        $_SESSION['admission_id']=$admission_id;
        header('location:admission_form_print.php');
    }
?>
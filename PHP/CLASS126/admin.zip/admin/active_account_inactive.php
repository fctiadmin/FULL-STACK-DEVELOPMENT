<?php
	require_once 'db_con.php';
	session_start();
    $status=base64_decode($_GET['status']);
    $update_inactive = mysqli_query($db_con , "UPDATE `admission_form` SET `status`='Inactive' WHERE `id`='$status'");
    if($update_inactive){
        header('location:admin_index.php?page=student_active_account');
    }
?>
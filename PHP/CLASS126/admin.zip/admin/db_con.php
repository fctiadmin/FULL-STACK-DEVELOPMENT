<?php 
$db_con = mysqli_connect("localhost" , "root" , "" , "php_full_project");
?>
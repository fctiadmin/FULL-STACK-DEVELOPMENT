<?php
	require_once 'db_con.php';
	session_start();
    $student_id=base64_decode($_GET['student_id']);
    if($student_id){
        $_SESSION['student_id']=$student_id;
        header('location:admin_index.php?page=student_admin_index');
    }
?>
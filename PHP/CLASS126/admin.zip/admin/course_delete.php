<?php
require("db_con.php");
session_start();
$course_id=base64_decode($_GET['course_id']);
$delete_data = mysqli_query($db_con , "DELETE FROM `all_courses` WHERE `id`='$course_id'");
if($delete_data){
    header('location:admin_index.php?page=all_course');
}
?>
<?php
	require_once 'db_con.php';
	session_start();
    $status=base64_decode($_GET['status']);
    $status_data_select = mysqli_query($db_con , "SELECT * FROM `admission_form` WHERE `id`='$status'");
    $status_data_fatch = mysqli_fetch_assoc($status_data_select);
    if($status_data_fatch['status'] == 'Inactive'){
        $update_active = mysqli_query($db_con , "UPDATE `admission_form` SET `status`='Active' WHERE `id`='$status'");
        if($update_active){
            header('location:admin_index.php?page=all_student_account_list');
        }
    }else{
        $update_inactive = mysqli_query($db_con , "UPDATE `admission_form` SET `status`='Inactive' WHERE `id`='$status'");
        if($update_inactive){
            header('location:admin_index.php?page=all_student_account_list');
        }
    }

?>
